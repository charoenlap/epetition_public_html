	<div class="footer">
      <div class="container">
        <div class="row">
          <?php echo $footer; ?>
        </div>
      </div>
    </div>
</body>
</html>